from app import app

@app.route('/hw')
def home():
   return "hello world!"
